DeepCode Quiet Terminal SC

Four OFL-derived fixed-cell faces for terminal rendering. ASCII: 500 units; CJK: 1000; UPM: 1000.
Reading preserves Libertinus Sans letterforms fitted to the terminal grid; Mono uses Maple Mono.
Kai uses LXGW WenKai CJK, Sans uses Resource Han Rounded from Maple Mono CN.
GUI proportional fonts are unchanged. Keep all accompanying OFL notices.
