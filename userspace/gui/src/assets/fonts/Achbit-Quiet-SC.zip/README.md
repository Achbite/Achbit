# Achbit Quiet SC

| 内置选项 | 字体家族 | 中文风格 |
| --- | --- | --- |
| 温和阅读 · 文楷 | Achbit Quiet Reading SC | 文楷 |
| 温和阅读 · 无衬线 | Achbit Quiet Reading Sans SC | 圆润黑体 |
| 紧凑终端 · 文楷 | Achbit Quiet Mono Kai SC | 文楷 |
| 紧凑终端 · 无衬线 | Achbit Quiet Mono SC | 圆润黑体 |

温和阅读两版保留相同的比例字宽无衬线英文；紧凑终端两版保留相同的等宽英文，中英文按 1:2 字宽排列。
文楷是中文书写风格，不等同于西文衬线体。无衬线两版的中英文均采用无衬线字形。

解压后安装所需的 TTF（macOS 使用字体册；Windows 右键安装），再从 Achbit 的字体详情导出并导入终端配置。
配置只选择字形和字号；启动 Achbit TUI 使用原有启动命令。
温和阅读使用比例字宽，独立 TUI 的严格网格布局建议选择紧凑终端。

All four fonts are renamed SIL OFL 1.1 derivatives. The accompanying notices must remain with redistributed fonts.
Reading Latin: Libertinus Sans 7.051. Mono Latin: Maple Mono NL CN 7.9.
Kai CJK: LXGW WenKai 1.522. Sans CJK and remaining glyphs: Maple Mono NL CN 7.9 (Resource Han Rounded).
These are not Claude or Optima fonts.
Regular only. No donor GSUB/GPOS or handcrafted small-size hinting.

The full WOFF2 fonts have the same cmap as their TTFs, not specimen subsets. sources.json records original downloads. To reproduce outlines, run build_fonts.py with fonttools 4.67.0 and brotli 1.2.0 inside the development container. Use --source-dir for the original fonts and --output-dir for generated TTFs and the receipt. The script also writes full WOFF2 fonts and the ZIP containing all four TTFs and these notices next to itself.
